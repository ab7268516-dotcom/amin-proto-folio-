# HANDOFF — Amin Hasan Portfolio Intro
1. বিষয়: রেফারেন্স ভিডিওর (reference.mp4) মতো Portfolio intro, ২৫ সেকেন্ড, নাম = Amin Hasan
2. সেটিংস: 16:9 1920×1080, 30fps, কালার = কালো + লাইম/সবুজ (#b6ff1a, #6fd400), ফন্ট = Robot Go + Geetanjali Academic Italic, স্টাইল = রেফারেন্সের Glossy/Glass + Kinetic
3. সিন: Hero (০–১১.৬s) লেখা হয়েছে · Arc ট্রানজিশন লেখা হয়েছে · Short-form (১১.৪–১৬s) প্লেসহোল্ডার · Long-form (১৬–২৫s) প্লেসহোল্ডার
4. সন্দেহ: Remotion ও নেটওয়ার্ক না থাকায় স্টিল/রেন্ডার যাচাই হয়নি (UNVERIFIED)। টেক্সট রেফারেন্সের মতোই রাখা। ক্লিপ কার্ডগুলো প্লেসহোল্ডার। SFX আর্কাইভ (7z) খোলা যায়নি, তাই SFX সিন্থেসাইজ করা (scripts/make_sfx.py)। SRT নেই, সময় রেফারেন্স ভিডিও থেকে আনুমানিক।
5. রেন্ডার: npx remotion render src/index.ts Main out/video.mp4 --codec h264 --crf 17
6. পরবর্তী ধাপ: নেটওয়ার্ক থাকা পরিবেশে npm install → স্টিল যাচাই (frame 60, 150, 240, 420, 600) → ক্লিপ ও লেখা ঠিক করা → রেন্ডার
