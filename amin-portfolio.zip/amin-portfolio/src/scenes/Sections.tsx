import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {C, CONTENT, F, ease, sec} from '../theme';
import {ClipCard, MaskReveal} from './parts';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const Title: React.FC<{text: string; start: number}> = ({text, start}) => (
  <MaskReveal start={start} style={{position: 'absolute', left: 0, right: 0, top: 70, textAlign: 'center'}}>
    <span style={{fontFamily: F.display, fontSize: 54, color: '#1a1a1a', letterSpacing: 0}}>{text}</span>
  </MaskReveal>
);

// লোকাল ফ্রেম: এই সিন 0 থেকে শুরু (Sequence এর ভেতরে)
export const ShortForm: React.FC = () => {
  const f = useCurrentFrame();
  const out = interpolate(f, [sec(4) - 8, sec(4)], [1, 0], clamp);
  return (
    <AbsoluteFill style={{background: C.paper, opacity: out}}>
      <Title text={CONTENT.short} start={4} />
      <div style={{position: 'absolute', left: 0, right: 0, top: 200, display: 'flex', justifyContent: 'center', gap: 40}}>
        {[130, 260, 20, 320].map((h, i) => (
          <ClipCard key={i} w={380} h={720} hue={h} label="Your clip" start={14} i={i} />
        ))}
      </div>
    </AbsoluteFill>
  );
};

export const LongForm: React.FC = () => {
  const f = useCurrentFrame();
  const out = interpolate(f, [sec(8.5) - 10, sec(8.5)], [1, 0], clamp);
  return (
    <AbsoluteFill style={{background: C.paper, opacity: out}}>
      <Title text={CONTENT.long} start={4} />
      <div style={{position: 'absolute', left: 0, right: 0, top: 190, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 36, padding: '0 160px'}}>
        {[140, 215, 30, 300].map((h, i) => (
          <ClipCard key={i} w={780} h={360} hue={h} label="Your clip" start={14} i={i} />
        ))}
      </div>
    </AbsoluteFill>
  );
};

// সবুজ আর্ক ট্রানজিশন (হিরো → সেকশন)
export const ArcTransition: React.FC = () => {
  const f = useCurrentFrame();
  const t = interpolate(f, [0, 22], [0, 1], {...clamp, easing: ease.inOut});
  const o = interpolate(f, [22, 34], [1, 0], clamp);
  return (
    <AbsoluteFill style={{opacity: o}}>
      <div style={{position: 'absolute', left: '-25%', width: '150%', height: '170%', borderRadius: '50%',
        background: C.lime, top: `${100 - t * 170}%`, boxShadow: `0 0 80px ${C.lime}`}} />
      <div style={{position: 'absolute', left: '-25%', width: '150%', height: '170%', borderRadius: '50%',
        background: C.paper, top: `${112 - t * 170}%`}} />
    </AbsoluteFill>
  );
};
