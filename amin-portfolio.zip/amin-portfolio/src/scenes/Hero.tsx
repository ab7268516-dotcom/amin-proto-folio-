import React from 'react';
import {AbsoluteFill, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {C, CONTENT, F, SPRING, ease, sec} from '../theme';
import {Backdrop, GrainVignette, MaskReveal, StaggerLetters, Star} from './parts';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

export const Hero: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();

  const tPortrait = spring({frame: f - sec(3), fps, config: SPRING.soft});
  const tCard = spring({frame: f - sec(5), fps, config: SPRING.pop});
  const tBadge = spring({frame: f - sec(7.2), fps, config: SPRING.pop});
  const nameWipe = interpolate(f - sec(4.6), [0, 22], [0, 100], {...clamp, easing: ease.out});
  const hiOp = interpolate(f - sec(4.3), [0, 12], [0, 1], clamp);
  const exit = interpolate(f, [sec(11.2), sec(11.6)], [1, 0], {...clamp, easing: ease.in});
  const breathe = Math.sin(f / 40) * 5;

  return (
    <AbsoluteFill style={{opacity: exit}}>
      <Backdrop />

      {/* PORTFOLIO — ফ্রেমের উপরের অংশে বিশাল */}
      <div style={{position: 'absolute', left: 0, right: 0, top: 150, transform: `scale(${1 + f * 0.0002})`}}>
        <StaggerLetters text="PORTFOLIO" start={0} size={440} gap={4} />
      </div>
      {/* নিচে ফেড — ছবির পেছনে গভীরতা */}
      <div style={{position: 'absolute', left: 0, right: 0, top: 380, height: 300,
        background: `linear-gradient(180deg, transparent, ${C.bg})`, opacity: tPortrait * 0.85}} />

      {/* Video editor & Visual Storyteller */}
      <MaskReveal start={sec(2.2)} style={{position: 'absolute', left: 150, top: 120}}>
        <span style={{fontFamily: F.display, fontSize: 40, color: C.white, letterSpacing: 0}}>{CONTENT.role1}</span>
      </MaskReveal>
      <MaskReveal start={sec(2.4)} style={{position: 'absolute', left: 0, right: 0, top: 120, textAlign: 'center'}}>
        <span style={{fontFamily: F.display, fontSize: 40, color: C.lime, letterSpacing: 0}}>&amp;</span>
      </MaskReveal>
      <MaskReveal start={sec(2.6)} style={{position: 'absolute', right: 150, top: 120}}>
        <span style={{fontFamily: F.display, fontSize: 40, color: C.white, letterSpacing: 0}}>{CONTENT.role2}</span>
      </MaskReveal>

      {/* পোর্ট্রেট */}
      <div style={{position: 'absolute', left: 560, top: 250, width: 800, height: 1100,
        opacity: tPortrait, transform: `translateY(${(1 - tPortrait) * 160 + breathe}px) scale(${0.94 + tPortrait * 0.06})`,
        filter: 'drop-shadow(0 0 50px rgba(111,212,0,0.35))'}}>
        <Img src={staticFile('img/portrait.png')} style={{width: '100%', height: 'auto', display: 'block'}} />
      </div>

      {/* Hi I am + নাম */}
      <div style={{position: 'absolute', left: 130, top: 600, opacity: hiOp}}>
        <div style={{fontFamily: F.script, fontStyle: 'italic', fontSize: 52, color: C.white, marginLeft: 40}}>Hi I am</div>
        <div style={{fontFamily: F.script, fontStyle: 'italic', fontSize: 130, lineHeight: 1.05, color: C.lime,
          clipPath: `inset(0 ${100 - nameWipe}% 0 0)`, textShadow: '0 0 30px rgba(182,255,26,0.45)', whiteSpace: 'nowrap'}}>
          {CONTENT.name}
        </div>
      </div>

      {/* Glass কার্ড */}
      <div style={{position: 'absolute', left: 90, top: 770, width: 700, height: 250,
        opacity: tCard, transform: `translateY(${(1 - tCard) * 80}px) scale(${0.92 + tCard * 0.08})`,
        borderRadius: 28, padding: '22px 28px', boxSizing: 'border-box',
        background: 'linear-gradient(135deg, rgba(120,200,10,0.55), rgba(40,100,0,0.45))',
        border: '1.5px solid rgba(182,255,26,0.5)', backdropFilter: 'blur(14px)',
        boxShadow: '0 20px 60px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.35)'}}>
        <div style={{fontFamily: F.display, fontSize: 30, color: C.white, letterSpacing: 0}}>{CONTENT.summaryTitle}</div>
        <div style={{marginTop: 14, background: 'rgba(245,245,240,0.95)', borderRadius: 16, padding: '14px 18px',
          fontFamily: F.script, fontStyle: 'italic', fontSize: 24, lineHeight: 1.3, color: C.text}}>
          {CONTENT.summary}
        </div>
      </div>

      {/* 5+ years Experience ব্যাজ */}
      <div style={{position: 'absolute', left: 1150, top: 560, display: 'flex', alignItems: 'center', gap: 16,
        padding: '14px 26px', borderRadius: 20, background: C.white, opacity: tBadge,
        transform: `scale(${0.7 + tBadge * 0.3})`, boxShadow: '0 0 40px rgba(182,255,26,0.55)'}}>
        <div style={{fontFamily: F.display, fontSize: 46, color: C.text, lineHeight: 1}}>5+</div>
        <div style={{width: 2, height: 40, background: '#bbb'}} />
        <div style={{fontFamily: F.display, fontSize: 28, color: C.text}}>Experience</div>
      </div>

      {/* স্কিল লিস্ট */}
      <div style={{position: 'absolute', left: 1400, top: 690, display: 'flex', flexDirection: 'column', gap: 26}}>
        {CONTENT.skills.map((s, i) => {
          const p = spring({frame: f - sec(7.8) - i * 6, fps, config: SPRING.pop});
          return (
            <div key={s} style={{display: 'flex', alignItems: 'center', gap: 20, opacity: p, transform: `translateX(${(1 - p) * 60}px)`}}>
              <Star color={C.star[i]} />
              <span style={{fontFamily: F.display, fontSize: 36, color: C.white, letterSpacing: 0}}>{s}</span>
            </div>
          );
        })}
      </div>

      <GrainVignette />
    </AbsoluteFill>
  );
};
